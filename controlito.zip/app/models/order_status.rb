class OrderStatus < ApplicationRecord
    has_many :fiverr_order
end
