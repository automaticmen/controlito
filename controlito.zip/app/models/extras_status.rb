class ExtrasStatus < ApplicationRecord
end
