class Server < ApplicationRecord
    has_many :fiverr_order
end
