class PaymentStatus < ApplicationRecord
  has_many:article
end
