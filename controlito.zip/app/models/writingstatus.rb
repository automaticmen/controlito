class Writingstatus < ApplicationRecord
  has_many :article
end
