class Writer < ApplicationRecord

end
