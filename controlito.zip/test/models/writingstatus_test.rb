require 'test_helper'

class WritingstatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
