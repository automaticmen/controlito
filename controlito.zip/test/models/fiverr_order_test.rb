require 'test_helper'

class FiverrOrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
