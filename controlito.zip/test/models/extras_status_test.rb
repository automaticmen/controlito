require 'test_helper'

class ExtrasStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
