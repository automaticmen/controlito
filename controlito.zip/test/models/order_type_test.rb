require 'test_helper'

class OrderTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
