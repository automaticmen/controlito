require 'test_helper'

class PaymentStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
